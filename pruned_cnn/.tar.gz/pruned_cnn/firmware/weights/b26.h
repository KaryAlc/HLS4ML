//Numpy array shape [10]
//Min -0.080258697271
//Max 0.088167607784
//Number of zeros 0

#ifndef B26_H_
#define B26_H_

#ifndef __SYNTHESIS__
output_dense_bias_t b26[10];
#else
output_dense_bias_t b26[10] = {-0.0802586973, 0.0226498581, 0.0081571545, 0.0400788859, -0.0105532436, 0.0212447308, -0.0683809742, -0.0428924412, 0.0881676078, 0.0261147544};
#endif

#endif

//Numpy array shape [10]
//Min -0.109204664826
//Max 0.152615070343
//Number of zeros 0

#ifndef B26_H_
#define B26_H_

#ifndef __SYNTHESIS__
output_dense_bias_t b26[10];
#else
output_dense_bias_t b26[10] = {-0.0522833019, 0.0247708485, 0.0112099666, -0.0207252316, -0.0207867045, -0.0181927923, 0.0422043689, -0.1092046648, 0.1526150703, 0.0464949831};
#endif

#endif

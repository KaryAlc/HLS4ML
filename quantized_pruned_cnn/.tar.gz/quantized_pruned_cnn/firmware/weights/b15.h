//Numpy array shape [42]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 42

#ifndef B15_H_
#define B15_H_

#ifndef __SYNTHESIS__
bias15_t b15[42];
#else
bias15_t b15[42] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#endif

#endif

//Numpy array shape [10]
//Min -0.125458091497
//Max 0.089219748974
//Number of zeros 0

#ifndef B23_H_
#define B23_H_

#ifndef __SYNTHESIS__
output_dense_bias_t b23[10];
#else
output_dense_bias_t b23[10] = {-0.1254580915, 0.0505750217, 0.0236531850, 0.0892197490, -0.0672501549, 0.0243918076, -0.0282466393, -0.0319776163, 0.0797045901, 0.0211536232};
#endif

#endif

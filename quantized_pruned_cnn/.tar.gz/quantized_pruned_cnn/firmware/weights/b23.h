//Numpy array shape [10]
//Min -0.166435480118
//Max 0.132306993008
//Number of zeros 0

#ifndef B23_H_
#define B23_H_

#ifndef __SYNTHESIS__
output_dense_bias_t b23[10];
#else
output_dense_bias_t b23[10] = {-0.1664354801, -0.0216709636, 0.0106217274, 0.1323069930, -0.0234276932, 0.0021035010, -0.0512613095, 0.0679787844, 0.1313402206, -0.0374191143};
#endif

#endif
